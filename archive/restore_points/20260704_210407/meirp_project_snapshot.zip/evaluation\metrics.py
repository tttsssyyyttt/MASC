"""Metrics computation for supply chain evaluation.

Includes: cost breakdown, fill rates, bullwhip effect (CV), inventory turnover.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np


def compute_metrics(info_history: List[dict], cfg=None) -> dict:
    """Compute evaluation metrics from a history of step info dicts.

    Args:
        info_history: list of info dicts from env.step()
        cfg: optional EnvConfig for additional metrics

    Returns:
        metrics: dict of metric values
    """
    if not info_history:
        return {}

    # Aggregate costs
    total_holding = sum(info["holding_costs"].sum() for info in info_history)
    total_backlog = sum(info["backlog_costs"].sum() for info in info_history)
    total_cost = total_holding + total_backlog

    n_steps = len(info_history)
    n_agents = info_history[0]["holding_costs"].shape[0]

    # Fill rates
    fill_rates = np.array([info["fill_rates"] for info in info_history])  # (T, N)
    avg_fill_rate = fill_rates.mean()
    min_fill_rate = fill_rates.min()
    per_agent_fill_rate = fill_rates.mean(axis=0)  # (N,)

    # Bullwhip effect: CV of orders / CV of demand per node
    # CV = std / mean (coefficient of variation)
    bullwhip_cv = _compute_bullwhip_cv(info_history)

    # Inventory turnover: total_demand / avg_inventory per node
    inventory_turnover = _compute_inventory_turnover(info_history)

    # Stockout rate = 1 - fill rate
    avg_stockout_rate = 1.0 - avg_fill_rate
    min_stockout_rate = 1.0 - min_fill_rate
    per_agent_stockout_rate = 1.0 - per_agent_fill_rate  # (N,)

    # Per-node costs
    per_node_holding = np.array([info["holding_costs"] for info in info_history]).sum(axis=0)  # (N,)
    per_node_backlog = np.array([info["backlog_costs"] for info in info_history]).sum(axis=0)  # (N,)
    per_node_cost = per_node_holding + per_node_backlog  # (N,)
    per_node_cost_per_step = per_node_cost / n_steps  # (N,)

    # Per-node average inventory and backlog levels
    per_node_avg_inventory = np.array([info["inventory"] for info in info_history]).mean(axis=0)  # (N,)
    per_node_avg_backlog = np.array(
        [info.get("backlog_costs", np.zeros(n_agents)) / np.maximum(cfg.B, 1e-10) if cfg is not None else np.zeros(n_agents)
         for info in info_history]
    ).mean(axis=0) if cfg is not None else np.zeros(n_agents)

    # Safe bullwhip mean (ignoring inf)
    finite_bw = np.where(np.isfinite(bullwhip_cv), bullwhip_cv, np.nan)
    avg_bullwhip_cv = float(np.nanmean(finite_bw)) if not np.all(np.isnan(finite_bw)) else 1.0

    metrics = {
        # Global aggregates
        "total_cost": total_cost,
        "avg_cost_per_step": total_cost / n_steps,
        "total_holding": total_holding,
        "total_backlog": total_backlog,
        "holding_ratio": total_holding / (total_cost + 1e-10),
        "backlog_ratio": total_backlog / (total_cost + 1e-10),
        "avg_fill_rate": avg_fill_rate,
        "min_fill_rate": min_fill_rate,
        "avg_stockout_rate": avg_stockout_rate,
        "min_stockout_rate": min_stockout_rate,
        # Per-node arrays (N,)
        "per_node_cost": per_node_cost,
        "per_node_cost_per_step": per_node_cost_per_step,
        "per_node_holding": per_node_holding,
        "per_node_backlog": per_node_backlog,
        "per_node_fill_rate": per_agent_fill_rate,
        "per_node_stockout_rate": per_agent_stockout_rate,
        "per_node_bullwhip_cv": bullwhip_cv,
        "per_node_turnover": inventory_turnover,
        "per_node_avg_inventory": per_node_avg_inventory,
        # Global means (for backward compatibility)
        "per_agent_fill_rate": per_agent_fill_rate,
        "bullwhip_cv": bullwhip_cv,
        "avg_bullwhip_cv": avg_bullwhip_cv,
        "inventory_turnover": inventory_turnover,
        "avg_inventory_turnover": inventory_turnover.mean(),
        "n_steps": n_steps,
    }

    # Per-layer aggregation if cfg is provided
    if cfg is not None:
        layers = np.array(cfg.layers)
        unique_layers = sorted(set(layers))
        per_layer = {}
        for l in unique_layers:
            mask = layers == l
            per_layer[f"layer_{l}_cost_per_step"] = float(per_node_cost_per_step[mask].mean())
            per_layer[f"layer_{l}_fill_rate"] = float(per_agent_fill_rate[mask].mean())
            per_layer[f"layer_{l}_stockout_rate"] = float(per_agent_stockout_rate[mask].mean())
            layer_bw = bullwhip_cv[mask]
            layer_bw_finite = layer_bw[np.isfinite(layer_bw)]
            per_layer[f"layer_{l}_bullwhip_cv"] = float(layer_bw_finite.mean()) if len(layer_bw_finite) > 0 else 1.0
            per_layer[f"layer_{l}_turnover"] = float(inventory_turnover[mask].mean())
            per_layer[f"layer_{l}_holding"] = float(per_node_holding[mask].mean())
            per_layer[f"layer_{l}_backlog"] = float(per_node_backlog[mask].mean())
        metrics["per_layer"] = per_layer
        metrics["n_layers"] = len(unique_layers)

    return metrics


def _compute_bullwhip_cv(info_history: List[dict]) -> np.ndarray:
    """Compute bullwhip effect per node.

    Uses the standard supply chain definition:
    bullwhip = Var(orders) / Var(demand)

    A ratio > 1 indicates demand variability amplification (bullwhip effect).
    A ratio < 1 indicates demand smoothing (good).
    A ratio of 0 means no ordering variability (agent not responding to demand).

    Returns:
        bullwhip_cv: shape (N,), variance ratio of orders / demand per node
    """
    n_agents = info_history[0]["order_qty"].shape[0]

    # Collect order and demand series
    orders = np.array([info["order_qty"] for info in info_history])  # (T, N)
    demands = np.array([info["demand"] for info in info_history])  # (T, N)

    bullwhip = np.zeros(n_agents)

    for i in range(n_agents):
        var_order = orders[:, i].var()
        var_demand = demands[:, i].var()

        if var_demand > 1e-10:
            bullwhip[i] = var_order / var_demand
        elif var_order > 1e-10:
            bullwhip[i] = np.inf
        else:
            bullwhip[i] = 1.0

    return bullwhip


def _compute_inventory_turnover(info_history: List[dict]) -> np.ndarray:
    """Compute inventory turnover rate per node.

    Turnover = total_demand_served / avg_inventory
    Higher turnover = more efficient inventory management.

    Returns:
        turnover: shape (N,), inventory turnover per node
    """
    n_agents = info_history[0]["inventory"].shape[0]

    demands = np.array([info["demand"] for info in info_history])  # (T, N)
    inventories = np.array([info["inventory"] for info in info_history])  # (T, N)

    total_demand = demands.sum(axis=0)  # (N,)
    avg_inventory = inventories.mean(axis=0)  # (N,)

    # Clip to avoid division by near-zero inventory
    turnover = total_demand / np.maximum(avg_inventory, 1e-3)

    return turnover
