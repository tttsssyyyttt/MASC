"""Full algorithm comparison: all RL + non-RL on all topologies.

Algorithms: BaseStock, (s,S), MILP, IQL, QMIX, MAPPO, SEA-IQL, SEA-QMIX, SEA-MAPPO
Topologies: 2layers, 3layers, 4layers
Config: hidden_dim=128, batch_size=64, GRU encoder, 200ep, 5 eval seeds

Usage (parallel per topology):
  python full_compare.py --topo 3layers
"""

import sys, os, time, json, argparse, warnings

warnings.filterwarnings("ignore")
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except:
        pass
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

import numpy as np
import torch

torch.backends.cudnn.benchmark = True

from meirp_project.core.config import from_yaml
from meirp_project.core.env import MEIRPEnv
from meirp_project.core.demand import DemandGenerator
from meirp_project.algorithms.registry import make_agent
from meirp_project.baselines.base_stock import BaseStockPolicy
from meirp_project.baselines.ss_policy import SSPolicy
from meirp_project.evaluation.metrics import compute_metrics
from meirp_project.collaboration.milp_advisor import MILPAdvisor
from meirp_project.collaboration.escalation import ThreeLevelEscalation

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_DIR = os.path.join(os.path.dirname(SCRIPT_DIR), "configs")


def _metric_mean(values):
    first = values[0]
    if isinstance(first, dict):
        keys = sorted(set().union(*(v.keys() for v in values)))
        return {
            k: _metric_mean([v[k] for v in values if k in v])
            for k in keys
        }
    if isinstance(first, np.ndarray):
        return np.mean(np.stack(values, axis=0), axis=0)
    if isinstance(first, (int, float, np.integer, np.floating)):
        return float(np.mean(values))
    return values


def _metric_std(values):
    first = values[0]
    if isinstance(first, dict):
        keys = sorted(set().union(*(v.keys() for v in values)))
        return {
            k: _metric_std([v[k] for v in values if k in v])
            for k in keys
        }
    if isinstance(first, np.ndarray):
        return np.std(np.stack(values, axis=0), axis=0)
    if isinstance(first, (int, float, np.integer, np.floating)):
        return float(np.std(values))
    return None


def aggregate_metrics(metrics_list):
    """Aggregate all metric fields without dropping per-node/per-layer data."""
    if not metrics_list:
        return {}

    result = {}
    keys = sorted(set().union(*(m.keys() for m in metrics_list)))
    for key in keys:
        values = [m[key] for m in metrics_list if key in m]
        if not values:
            continue
        result[key] = _metric_mean(values)
        std = _metric_std(values)
        if std is not None:
            result[f"{key}_std"] = std

    result["n_eval_seeds"] = len(metrics_list)
    return result


def to_jsonable(obj):
    """Convert numpy-heavy metrics to JSON-native structures."""
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer, np.floating)):
        return obj.item()
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    return obj


def eval_policy(agent, cfg, n_seeds=5, is_base=False, escalation=None, oracle_demand=False):
    ms = []
    for s in range(n_seeds):
        env = MEIRPEnv(cfg)
        demand_seq = None

        if oracle_demand:
            # Pre-generate TRUE terminal demands for the entire episode
            rng = np.random.default_rng(s)
            dgen = DemandGenerator(cfg, rng)
            T = cfg.episode_len
            demand_seq = np.array([dgen.generate(len(env.terminals)) for _ in range(T)], dtype=np.float64)
            # Pad with demand_mean beyond episode end for MILP oracle horizon
            pad_len = getattr(agent, 'planning_horizon', 15)
            pad = np.full((pad_len, len(env.terminals)), cfg.demand_mean, dtype=np.float64)
            demand_seq = np.concatenate([demand_seq, pad], axis=0)
            obs, _ = env.reset(seed=s, options={"demand_sequence": demand_seq[:T]})
        else:
            obs, _ = env.reset(seed=s)

        ih = []
        done = False
        step = 0
        while not done:
            if is_base == "milp":
                if oracle_demand and demand_seq is not None:
                    horizon = getattr(agent, 'planning_horizon', 15)
                    future = demand_seq[step:step + horizon]
                else:
                    future = None
                a = agent.get_action(env.inventory, env.backlog, env.pipeline, demand_forecast=future)
            elif is_base:
                a = agent.get_actions(env)
            else:
                a = agent.get_actions(obs, deterministic=True)
            if escalation and not is_base:
                if oracle_demand and demand_seq is not None:
                    future = demand_seq[step:step + 15]
                    a, _, _ = escalation.step_eval(obs, a, env, demand_forecast=future)
                else:
                    a, _, _ = escalation.step(obs, a, env)
            obs, r, term, trunc, info = env.step(a)
            done = term or trunc
            ih.append(info)
            step += 1
        ms.append(compute_metrics(ih, cfg))

    return aggregate_metrics(ms)


def train_rl(agent, cfg, escalation, n_ep, warmup, label):
    env = MEIRPEnv(cfg)
    R = []
    steps = 0
    for ep in range(n_ep):
        obs, _ = env.reset()
        ep_r = 0.0
        done = False
        while not done:
            rl_act = agent.get_actions(obs)
            if escalation:
                a, src, info = escalation.step(obs, rl_act, env)
            else:
                a = rl_act
            nobs, r, term, trunc, info = env.step(a)
            done = term or trunc
            # Always store original RL action (expert only helps execute better trajectories)
            agent.store_transition(obs, rl_act, r, nobs, np.full(cfg.num_nodes, float(term)))
            steps += 1
            # Off-policy (IQL, QMIX): step-based update when buffer has enough samples
            if hasattr(agent, 'batch_size') and len(agent.buffer) >= agent.batch_size and steps >= warmup:
                agent.update()
            ep_r += float(r.sum())
            obs = nobs
        # On-policy (MAPPO): episode-based update
        if not hasattr(agent, 'batch_size') and steps >= warmup:
            agent.update()
        R.append(ep_r)
        if (ep + 1) % 100 == 0:
            print(f"    [{label}] Ep{ep + 1}/{n_ep} R={np.mean(R[-50:]):.1f}")
    return R


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--topo", required=True, choices=["2layers", "3layers", "4layers", "custom"])
    p.add_argument("--ep", type=int, default=300)
    p.add_argument("--hard", action="store_true")
    p.add_argument("--config", type=str, default=None, help="Direct path to config YAML")
    p.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = p.parse_args()

    if args.config:
        cfg = from_yaml(args.config)
    else:
        suffix = "_hard" if args.hard else ""
        cfg = from_yaml(os.path.join(CFG_DIR, f"env_{args.topo}{suffix}.yaml"))
    obs_dim = 3 + 3 * cfg.lead_time
    N = cfg.num_nodes
    print(f"\n{'=' * 60}\n  {args.topo}: {N} nodes | max_order={cfg.max_order} | demand={cfg.demand_mean}\n{'=' * 60}")

    results = {}
    order = []

    # ===== Non-RL baselines =====
    for name, policy, base, oracle in [("BaseStock", BaseStockPolicy(cfg), True, False),
                                       ("(s,S)", SSPolicy(cfg), True, False),
                                       ("MILP", MILPAdvisor(cfg, planning_horizon=15), False, True)]:
        t0 = time.time()
        is_base_flag = "milp" if name == "MILP" else base
        r = eval_policy(policy, cfg, n_seeds=5, is_base=is_base_flag, oracle_demand=oracle)
        results[name] = r
        order.append(name)
        print(f"  {name:<12}: cost={r['avg_cost_per_step']:.1f} fill={r['avg_fill_rate']:.4f} bw={r['avg_bullwhip_cv']:.4f}")

    # ===== RL algorithms =====
    rl_configs = [
        ("IQL", "iql", dict(hidden_dim=128, lr=1e-3, gamma=0.99, buffer_capacity=20000, batch_size=64, epsilon_decay=9000, target_update_freq=100)),
        ("QMIX", "qmix", dict(hidden_dim=128, lr=5e-4, gamma=0.99, buffer_capacity=20000, batch_size=64, target_update_freq=100, mixer_hidden=32)),
        ("MAPPO", "mappo", dict(hidden_dim=128, lr_actor=3e-4, lr_critic=1e-3, gamma=0.99, entropy_coef=0.01)),
    ]

    for name, algo, kw in rl_configs:
        # Pure RL
        print(f"\n  [{name}] training {args.ep}ep...")
        agent = make_agent(algo, cfg, obs_dim=obs_dim, device=args.device, **kw)
        t0 = time.time()
        _ = train_rl(agent, cfg, None, args.ep, 500, name)
        t_pure = time.time() - t0
        r = eval_policy(agent, cfg)
        results[name] = r
        order.append(name)
        print(f"    {name:<12}: cost={r['avg_cost_per_step']:.1f} fill={r['avg_fill_rate']:.4f} bw={r['avg_bullwhip_cv']:.4f} time={t_pure:.0f}s")

        # SEA — k=3.0 for both training and eval
        sea_agent = make_agent(algo, cfg, obs_dim=obs_dim, device=args.device, **kw)
        esc_train = ThreeLevelEscalation(cfg, k_spc=3.0)
        t0 = time.time()
        _ = train_rl(sea_agent, cfg, esc_train, args.ep, 500, f"SEA-{name}")
        t_sea = time.time() - t0
        esc_eval = ThreeLevelEscalation(cfg, k_spc=3.0)
        r_sea = eval_policy(sea_agent, cfg, escalation=esc_eval, oracle_demand=True)
        sname = f"SEA-{name}"
        results[sname] = r_sea
        order.append(sname)
        s = esc_train.stats()
        print(f"    {sname:<12}: cost={r_sea['avg_cost_per_step']:.1f} fill={r_sea['avg_fill_rate']:.4f} bw={r_sea['avg_bullwhip_cv']:.4f} time={t_sea:.0f}s SPC={s['spc']:.2%} Exp={s['expert']:.2%}")

    # ===== Summary table =====
    print(f"\n  {'=' * 70}")
    print(f"  Results Summary: {args.topo}")
    print(f"  {'Algorithm':<16} {'Cost/Step':>10} {'Fill Rate':>10} {'Bullwhip':>10} {'Stockout':>10}")
    print(f"  {'-' * 56}")
    best_fill = max(results[n]["avg_fill_rate"] for n in order)
    best_cost = min(results[n]["avg_cost_per_step"] for n in order)
    for name in order:
        r = results[name]
        fm = " *" if abs(r["avg_fill_rate"] - best_fill) < 1e-6 else ""
        cm = " *" if abs(r["avg_cost_per_step"] - best_cost) < 1e-6 else ""
        print(f"  {name:<16} {r['avg_cost_per_step']:>10.1f}{cm} {r['avg_fill_rate']:>10.4f}{fm} {r['avg_bullwhip_cv']:>10.4f} {r['avg_stockout_rate']:>10.4f}")

    # ===== Save =====
    out = os.path.join(os.path.dirname(SCRIPT_DIR), "results", f"full_compare_{args.topo}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w') as f:
        json.dump(to_jsonable({"topo": args.topo, "results": results, "order": order}), f, indent=2)
    print(f"\n  Saved: {out}")


if __name__ == "__main__":
    main()
